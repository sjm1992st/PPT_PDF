# -*- coding: utf-8 -*-
# @Time    : 2019/1/17 16:49
# @Author  : shenjiamin
# @Mail    : shenjiamin@vivo.com
from tpot import TPOTRegressor
from sklearn.datasets import load_boston
from sklearn.model_selection import train_test_split
from dl_study.pre_data import data_


# housing = load_boston()

tpot = TPOTRegressor(generations=5, population_size=50, verbosity=2)
tpot.fit(data_.x_train_data, data_.y_train_data)
print(tpot.predict(data_.test_data))
tpot.export('tpot_boston_pipeline.py')